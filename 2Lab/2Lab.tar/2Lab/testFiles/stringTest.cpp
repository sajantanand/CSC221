#include <cstring>
#include <iostream>
using namespace std;

int main()
{
	string joe = "hello";
	cout << joe << endl;
	joe.clear();
	cout << joe << endl;
	return 0;
}
